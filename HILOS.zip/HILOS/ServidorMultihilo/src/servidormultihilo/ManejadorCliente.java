
package servidormultihilo;

/**
 *
 * @author Audias Guevara
 */

import java.io.*;
import java.net.*;
import java.text.SimpleDateFormat;
import java.util.Date;

class ManejadorCliente extends Thread {
    private Socket socket;
    private int clienteId;
    private PrintWriter salida;
    private BufferedReader entrada;

    public ManejadorCliente(Socket socket, int clienteId) {
        this.socket = socket;
        this.clienteId = clienteId;
    }

    @Override
    public void run() {
        try {
            salida = new PrintWriter(socket.getOutputStream(), true);
            entrada = new BufferedReader(new InputStreamReader(socket.getInputStream()));

            // Mensaje de bienvenida con marca de tiempo
            salida.println(obtenerFechaHora() + " ¡Bienvenido al servidor, Cliente " + clienteId + "!");

            String mensaje;
            while ((mensaje = entrada.readLine()) != null) {
                System.out.println(obtenerFechaHora() + " Mensaje recibido de Cliente " + clienteId + ": " + mensaje);

                // Respuesta predeterminada del servidor con marca de tiempo
                salida.println(obtenerFechaHora() + " Este mensaje es para ti: " + mensaje);
            }

        } catch (IOException e) {
            System.out.println("Error en la conexión con Cliente " + clienteId);
            e.printStackTrace();
        } finally {
            System.out.println("Cliente " + clienteId + " se ha desconectado.");
            try {
                socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    // Método para obtener la fecha y hora actuales
    private String obtenerFechaHora() {
        SimpleDateFormat formatoFechaHora = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return "[" + formatoFechaHora.format(new Date()) + "]";
    }
}

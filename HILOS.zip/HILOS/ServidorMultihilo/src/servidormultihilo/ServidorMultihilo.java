
package servidormultihilo;

/**
 *
 * @author Audias Guevara
 */

import java.io.*;
import java.net.*;

public class ServidorMultihilo {
    private static int puerto = 1234;

    public static void main(String[] args) {
        try (ServerSocket servidor = new ServerSocket(puerto)) {
            System.out.println("Servidor escuchando en el puerto " + puerto);

            int clienteId = 1;  // Identificador del cliente
            while (true) {
                Socket socket = servidor.accept();
                System.out.println("Cliente " + clienteId + " conectado desde: " + socket.getInetAddress());
                new ManejadorCliente(socket, clienteId).start();
                clienteId++;  // Incrementa el ID del cliente para el siguiente
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package cliente;

/**
 *
 * @author Audias Guevara
 */

import java.io.*;
import java.net.*;

public class Cliente {
    public static void main(String[] args) {
        String servidor = "localhost";  // Dirección del servidor
        int puerto = 1234;  // Puerto al que conectarse
        
        try (Socket socket = new Socket(servidor, puerto)) {
            PrintWriter salida = new PrintWriter(socket.getOutputStream(), true);
            BufferedReader entrada = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            BufferedReader lectorTeclado = new BufferedReader(new InputStreamReader(System.in));
            
            String respuestaServidor;
            while ((respuestaServidor = entrada.readLine()) != null) {
                System.out.println(respuestaServidor);  // Mostrar el mensaje del servidor

                String mensaje = lectorTeclado.readLine();  // Leer mensaje del usuario
                salida.println(mensaje);  // Enviar mensaje al servidor
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

